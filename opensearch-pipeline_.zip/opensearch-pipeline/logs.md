## Logstach Logs

- **full-logstash.log** contains all the logs transfered from filebeat to logstash and is converted into a structured format.
- Sturcture of the log template is in **/logstash/templates/syslog-template.json**