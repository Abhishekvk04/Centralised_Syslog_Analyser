## 💡 How to Import SLack Channel in OpenSearch Dashboard

1. Click on the left panel and select Dev Tools at th bottom.

2. Go to Dev Tools.

3. Paste the above .sh in the left panel(without the cURL headers).

4.Ctrl+ A and Hit Play ▶️ to create the detector.

5. Go to Notifications in the left panel and click on the channels to verify.