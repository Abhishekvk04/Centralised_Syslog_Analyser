## 💡 How to Import Anomaly detectors in OpenSearch Dashboard
1. Click on the left panel and select Dev Tools at th bottom.

2. Go to Dev Tools.

3. Paste the above JSON in the left panel(without the cURL headers).

4.Ctrl+ A and Hit Play ▶️ to create the detector.