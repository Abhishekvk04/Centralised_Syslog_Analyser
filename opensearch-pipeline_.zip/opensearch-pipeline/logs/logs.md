# Syslog Logs 

## This contains various types of logs
1. Network logs
2. Application logs
3. System logs
4. Security logs
5. Audit logs
6. Performance logs
7. Error logs
8. Debug logs
9. Trace logs
10. Access logs
11. Recovery
12. Monitoring
13. Troubleshooting
14. Configuration
15. Deployment
16. Remote
17. docker
18. Testing

#### -> Combined logs contains all kind of logs 
#### -> Message logs contains message logs
#### -> Network folder contains network logs : YYYY-MM-DD.log format
#### -> Remote folder contains remote logs : <Container-ID>.log format